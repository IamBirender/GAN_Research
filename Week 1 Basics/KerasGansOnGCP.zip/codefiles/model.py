import os
from typing import Tuple

from tensorflow import keras
import tensorflow as tf


def log_loss(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    difference = y_true - y_pred
    absolute_difference = keras.backend.maximum(difference, -difference)
    log_absolute_difference = keras.backend.log(absolute_difference)
    return keras.backend.mean(log_absolute_difference)


def build_generator(batch_size: int = 32) -> keras.models.Model:
    random_inputs = keras.layers.Input(tensor=keras.backend.zeros((batch_size, 1)))
    random_sample = keras.layers.Lambda(
        lambda _: keras.backend.random_uniform((batch_size, 1, 1, 256))
    )(random_inputs)

    conv = random_sample
    for block in range(4, 0, -1):
        filters = 4 ** block
        conv = keras.layers.UpSampling2D(size=(4, 4))(conv)
        conv = keras.layers.Conv2D(filters=filters, kernel_size=(1, 1))(conv)
        residual = conv
        for layer in range(3):
            residual = keras.layers.Conv2D(filters=filters, kernel_size=(3, 3), padding='same')(residual)
            residual = keras.layers.Activation('elu')(residual)
        conv = keras.layers.Add()([conv, residual])

    conv = keras.layers.Conv2D(filters=3, kernel_size=(1, 1), activation='sigmoid')(conv)
    return keras.models.Model(inputs=random_inputs, outputs=conv)


def build_discriminator() -> keras.models.Model:
    inputs = keras.layers.Input((256, 256, 3), name='image_inputs')
    conv = inputs
    for block in range(5):
        filters = 2 ** block
        conv = keras.layers.Conv2D(filters=filters, kernel_size=(1, 1))(conv)
        residual = conv
        for layer in range(3):
            residual = keras.layers.Conv2D(filters=filters, kernel_size=(3, 3), padding='same')(residual)
            residual = keras.layers.Activation('elu')(residual)
        conv = keras.layers.Add()([conv, residual])
        conv = keras.layers.AveragePooling2D()(conv)

    final = keras.layers.GlobalAveragePooling2D()(conv)
    outputs = keras.layers.Dense(1, activation='sigmoid', name='is_real')(final)
    return keras.models.Model(inputs=inputs, outputs=outputs)


def build_model() -> Tuple[keras.models.Model, keras.models.Model]:
    if os.path.exists('generator.hdf5'):
        generator = keras.models.load_model('generator.hdf5', custom_objects={
            'log_loss': log_loss
        })
        print("Loaded generator.")
    else:
        generator = build_generator()
    if os.path.exists('discriminator.hdf5'):
        discriminator = keras.models.load_model('discriminator.hdf5', custom_objects={
            'log_loss': log_loss
        })
        print("Loaded discriminator.")
    else:
        discriminator = build_discriminator()

    return generator, discriminator
