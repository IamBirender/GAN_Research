from tensorflow import keras
import numpy as np
from typing import Dict, Tuple
import os
import cv2


class DataLoader(keras.utils.Sequence):

    def __init__(self: 'DataLoader', load_from_folder: str, batch_size: int = 32) -> None:
        self.data_files = np.array([os.path.join(load_from_folder, file) for file in os.listdir(load_from_folder)])
        self.batch_size = batch_size
        self.shuffle()

    def __len__(self: 'DataLoader') -> int:
        return len(self.data_files) // self.batch_size

    def __getitem__(self: 'DataLoader', index: int) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray]]:
        selection = self.data_files[index * self.batch_size: (index + 1) * self.batch_size]
        images = np.array([
            cv2.resize(cv2.imread(image_location, cv2.IMREAD_COLOR).astype(float), (256, 256), cv2.INTER_LINEAR)
            for image_location in selection
        ])
        labels = np.array([1 if 'dog'.casefold() in image_location.casefold() else 0 for image_location in selection])
        return {
            'image_inputs': images / 255.
        }, {
            'is_dog': labels
        }

    def shuffle(self):
        self.data_files = np.random.permutation(self.data_files)

    def on_epoch_end(self):
        self.shuffle()
