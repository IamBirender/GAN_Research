import argparse

import cv2
import numpy as np
from tensorflow import keras
import subprocess
import os
import zipfile

from codefiles.data_loader import DataLoader
from codefiles.model import build_model, log_loss

try:
    import psutil
    N_WORKERS = psutil.cpu_count()
except ImportError:
    # Safe assumption - 4 cores.
    N_WORKERS = 4


def run_discriminator_step(generator: keras.models.Model, discriminator: keras.models.Model, training_data):
    random_minibatch = training_data[np.random.randint(len(training_data))][0]
    random_minibatch['is_real'] = np.ones(shape=(random_minibatch['image_inputs'].shape[0],))
    random_noise = generator.predict([], steps=1)
    random_noise = {
        'image_inputs': random_noise,
        'is_real': np.zeros((random_noise.shape[0],))
    }
    minibatch = {
        'image_inputs': np.concatenate((random_noise['image_inputs'], random_minibatch['image_inputs']), axis=0),
        'is_real': np.concatenate((random_noise['is_real'], random_minibatch['is_real']), axis=0)
    }
    return discriminator.train_on_batch(minibatch['image_inputs'], minibatch['is_real'])


def run_generator_step(overall):
    return overall.train_on_batch([], np.ones((overall.input.shape[0],)))


def training_loop(generator, discriminator, overall, training_data, num_iterations, learning_rate):
    num_steps = 4
    for iteration in range(num_iterations):

        generator.trainable = False
        discriminator.trainable = True
        discriminator.compile(loss=log_loss, optimizer=keras.optimizers.Adam(lr=learning_rate))

        for step in range(num_steps):
            discriminator_step = run_discriminator_step(generator, discriminator, training_data)
            if np.isnan(discriminator_step) or np.isinf(discriminator_step) or np.isinf(-discriminator_step):
                print("Discriminator diverged.")
                return
            print("Iteration {} of {}, discriminator step {} of {}: {}".format(
                iteration + 1,
                num_iterations,
                step + 1,
                num_steps,
                discriminator_step
            ))

        generator.trainable = True
        discriminator.trainable = False
        overall.compile(loss=log_loss, optimizer=keras.optimizers.Adam(lr=learning_rate))

        generator_step = run_generator_step(overall)
        if np.isnan(generator_step) or np.isinf(generator_step) or np.isinf(-generator_step):
            print("Generator diverged.")
            return
        print("Iteration {} of {}, generator: {}".format(
            iteration + 1, num_iterations, generator_step
        ))


def main(args: argparse.Namespace) -> None:
    learning_rate = float(args.learning_rate)
    num_iterations = int(args.num_iterations)

    if args.data_files.startswith('gs'):
        subprocess.check_call([
            'gsutil', 'cp', args.data_files, '/tmp/train_data.zip'
        ])
    else:
        with open(args.data_files, 'rb') as inp:
            with open('/tmp/train_data.zip', 'wb') as outp:
                outp.write(inp.read())

    if not os.path.exists('/tmp/train/'):
        os.makedirs('/tmp/train/')
    with zipfile.ZipFile('/tmp/train_data.zip', 'r') as zipped:
        zipped.extractall('/tmp/train/')
    os.remove('/tmp/train_data.zip')

    training_data = DataLoader('/tmp/train')

    generator, discriminator = build_model()
    overall = discriminator(generator.outputs)
    overall = keras.models.Model(inputs=generator.inputs, outputs=overall)

    discriminator.compile(loss=log_loss, optimizer=keras.optimizers.Adam(lr=learning_rate))
    generator.compile(loss=log_loss, optimizer=keras.optimizers.Adam(lr=learning_rate))
    overall.compile(loss=log_loss, optimizer=keras.optimizers.Adam(lr=learning_rate))
    training_loop(generator, discriminator, overall, training_data, num_iterations, learning_rate)

    created_batch = generator.predict([], steps=1)
    for i in range(16):
        created = created_batch[i]
        cv2.imwrite('created_{}.png'.format(i), created * 255)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--learning_rate',
        help="The learning rate to be used while training the cats and dogs model.",
        required=True
    )
    parser.add_argument(
        '--num_iterations',
        required=False,
        default=10,
        help="The number of training iterations to perform."
    )
    parser.add_argument(
        '--job-dir',
        required=False,
        default='.',
        help='Current working directory (job directory) to which checkpoints should be saved.'
    )
    parser.add_argument(
        '--data_files',
        required=False,
        default='train_data.zip',
        help='Zipped file containing training data.'
    )
    main(parser.parse_args())
