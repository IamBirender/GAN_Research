BUCKET_PATH="gs://ekstrum-gan-seminar"

gsutil cp train_data.zip ${BUCKET_PATH}/gan-demo/train_data.zip
