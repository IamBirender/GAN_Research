from setuptools import setup, find_packages

setup(
    name='gan_example',
    install_requires=[
        'psutil',
        'opencv-python',
        'tensorflow-gpu==1.14.0',
        'numpy'
    ],
    packages=find_packages()
)
