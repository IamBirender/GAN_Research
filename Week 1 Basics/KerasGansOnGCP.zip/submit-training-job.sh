BUCKET_PATH="gs://ekstrum-gan-seminar"
BUCKET_REGION="us-east1"

gcloud ai-platform jobs submit training $1 --python-version 3.5 --scale-tier BASIC_GPU --job-dir ${BUCKET_PATH}/gan-demo/job --runtime-version 1.14 --module-name codefiles.cats_and_dogs --package-path codefiles/ --region ${BUCKET_REGION} -- --data_files ${BUCKET_PATH}/gan-demo/train_data.zip --learning_rate 0.0001
