# MaskGAN
* Reproduced the result of MaskGAN from ICLR 2018 using TensorFlow.
* Improved the overall text generation result by using the padding preprocessing technique.
* [Report](/final-report.pdf)